xtabs <-. funci�n (f�rmula = ~, data = parent.frame (), subconjunto, escaso = FALSO,
		  na.action, excluir a = c (NA, NaN), drop.unused.levels = FALSO)
{
    if (&& faltantes (f�rmula) que falta (datos))
	stop ("debe proporcionar ya sea" f�rmula "o" datos "")
    if (! missing (f�rmula)) {
	# # Tenemos que forzar el argumento formula ahora, pero model.frame
	# # Ser� obligar a la versi�n original m�s tarde.
	f�rmula <- as.formula (f�rmula)
	if (! hereda (f�rmula "f�rmula"))
	    stop ("" f�rmula "que falta o incorrecta")
    }
    if ((todos los t�rminos (attr (f�rmula de datos = datos), "Orden")> 1))
	stop ("interacciones no est�n permitidos")
    m <- match.call (expand.dots = FALSO)
    if (is.matrix (datos eval (m $, parent.frame ())))
	m $ data <- as.data.frame (datos)
    m $ ... <- M $ excluye <- m $ drop.unused.levels <- m $ escasa <- NULL
    m [[1L]] <- cita (estad�sticas :: model.frame)
    mf <- eval (m, parent.frame ())
    if (length (f�rmula) == 2 l) {
	por <- mf
	y <- NULL
    }
    else {
	i <- attr (attr (mf, "t�rminos"), "respuesta")
	por <- mf [-i]
	y <- mf [[i]]
    }
    has.exclude <- falta (excluir)
    por <- lapply (por, la funci�n (u) {
        if (is.factor (u)!) u <- Factor (u, exclude = exclusi�n)
        else if (has.exclude) # No deje caer NA de los factores menos pedido expl�citamente
            u <- Factor (as.character (u),
                        niveles = setdiff (niveles (u), excluyen),
                        exclude = NULL)
	u [, gota = drop.unused.levels]
    })
    if (! escasa) {# # id�nticas a las estad�sticas :: xtabs
	x <-
	    if (is.null (y))
		do.call ("mesa", por)
	    else if (NCOL (y) == 1 l)
		tapply (y, por, suma)
	    else {
		z <- lapply (as.data.frame (y), tapply, por, suma)
		array (no listados (z),
		      dim = c (dim (z [[1L]]), longitud (z)),
		      dimnames = c (dimnames (z [[1L]]), la lista (los nombres (z))))
	    }
	x [is.na (x)] <- 0
	clase (x) <- c ("xtabs", "mesa")
	attr (x, "call") <- match.call ()
	x

    } Else {# # escasa
	if (longitud (por)! = 2L)
	    stop (gettextf ("% s se aplica s�lo a tablas de doble entrada",
                          "Xtabs (*, escaso = TRUE)"),
                 domain = NA)
        (.) # # LoadNamespace es muy r�pida, una vez que * se * carga:
	if (is.null (TryCatch error (loadNamespace ("Matrix") = function (e) NULL)))
            stop (gettextf ("% s paquete de necesidades 'Matrix' instalado correctamente",
                          "Xtabs (*, escaso = TRUE)"),
                 domain = NA)
        si (la longitud (i.ex <- �nico (no listados (lapply (por, la funci�n (f) que (is.na (f)))))))
            por <- lapply (por, `[`,-i.ex)
	<- filas de [[1L]]
	cols <- por [[2L]]
	rl <- niveles (filas)
	cl <- niveles (cols)
	if (is.null (y))
	    y <- rep.int (1, length (filas))
	como (new ("dgTMatrix",
	       i = as.integer (filas) - 1L,
	       j = as.integer (cols) - 1L,
	       x = as.double (y),
	       Dim = c (longitud (rl), longitud (cl)),
	       Dimnames = list (rl, cl)), "CsparseMatrix")
    }
}

print.xtabs <- funci�n (x, ...)
{
    buey <- x
    attr (x, "call") <- NULL
    print.table (x, ...)
    invisible (buey)
}
# Funciones de formato comunes a los talleres y complementos del módulo multivariado
# (MEYB 2026-II). Se cargan con source("formato.R").

# Números con uno, dos y tres decimales fijos para el texto (0.180 y no 0.18)
f1 <- function(x) formatC(x, format = "f", digits = 1)
f2 <- function(x) formatC(x, format = "f", digits = 2)
f3 <- function(x) formatC(x, format = "f", digits = 3)

# Números con coma decimal para los párrafos de reporte
coma <- function(x, d = 2) formatC(x, format = "f", digits = d, decimal.mark = ",")

# Valor p de una fila de una tabla de anova() o adonis2()
p_de <- function(a, fila = 1) a$`Pr(>F)`[fila]

# Tabla con el formato del módulo
tabla <- function(x, digits = 3, ...) {
  x %>%
    kableExtra::kbl(booktabs = TRUE,
                    digits = digits,
                    ...) %>%
    kableExtra::kable_classic(full_width = FALSE) %>%
    kableExtra::row_spec(0, bold = TRUE)
}

# Ubicar un archivo de datos: en la carpeta del .qmd o en la raíz del proyecto
ruta_datos <- function(archivo) {
  rutas <- c(archivo,
             file.path("..", archivo),
             file.path("..", "..", archivo))
  ruta <- rutas[file.exists(rutas)][1]
  if (is.na(ruta)) stop("No se encontró ", archivo,
                        ": cópielo en la carpeta de este .qmd o en la raíz del proyecto.")
  ruta
}
